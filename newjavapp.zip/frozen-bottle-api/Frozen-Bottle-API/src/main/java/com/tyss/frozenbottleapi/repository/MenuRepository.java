package com.tyss.frozenbottleapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tyss.frozenbottleapi.entity.Menu;

public interface MenuRepository extends JpaRepository<Menu, Integer> {

}
