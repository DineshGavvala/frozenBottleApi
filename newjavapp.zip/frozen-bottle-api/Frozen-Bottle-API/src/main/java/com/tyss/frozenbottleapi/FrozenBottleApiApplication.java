package com.tyss.frozenbottleapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FrozenBottleApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FrozenBottleApiApplication.class, args);
	}

}
